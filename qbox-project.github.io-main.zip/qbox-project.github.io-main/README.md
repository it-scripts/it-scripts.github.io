# Qbox Project Documentation

## Local Development

First, run `pnpm i` to install the dependencies.

Then, run `pnpm dev` to start the development server and visit localhost:3000.

## Acknowledgements

- [`shuding/nextra-docs-template`](https://github.com/shuding/nextra-docs-template) - the template used
- [`overextended/overextended.github.io`](https://github.com/overextended/overextended.github.io) - much of the styling copied over from here
